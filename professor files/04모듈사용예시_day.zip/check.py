# TOOLS 로 부터 뭔가 가져와 ~~

# 1번 방법
from calc import tools
print(tools.add(1, 2))
print(tools.sub(3, 4))

# # 2번 방법
# from calc.tools import add, sub
# # from calc.tools import * #함수들을 다 치기 귀찮으면 이렇게 *을 써서 모두 가져와요!
# print(add(1, 2))
# print(add(3, 4))

# # 3번 방법 (이거는 왜 소개 안해줘!!!)
# import calc.tools
# print(calc.tools.add(1, 2))
# print(calc.tools.add(3, 4))