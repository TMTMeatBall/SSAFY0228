arr = [('길동', 80), ('가희', 80), ('철수', 20), ('남길', 50)]

arr = sorted(arr, key=lambda x: (x[1], x[0]))

print(arr)

import requests